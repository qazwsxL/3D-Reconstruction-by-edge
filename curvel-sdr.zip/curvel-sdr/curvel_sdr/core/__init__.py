"""Core QCQP/SDR matrix construction and recovery utilities."""

from .qcqp_sdr_core_eq5_edge import (
    EdgeCorrespondence,
    build_eq5_sdr_problem,
    solve_edge_correspondence_eq5_sdr,
    recover_edge_solution_from_arc_lengths,
)
