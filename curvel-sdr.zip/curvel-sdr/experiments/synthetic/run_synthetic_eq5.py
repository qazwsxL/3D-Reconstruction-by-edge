#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from curvel_sdr.core.geometry import pairwise_fundamentals, project
from curvel_sdr.core.qcqp_sdr_core_eq5_edge import EdgeCorrespondence, solve_edge_correspondence_eq5_sdr
from curvel_sdr.visualization.plot_edges import plot_edge_refinement


def make_problem():
    P1 = np.array([[1, 0, 0, 0.00], [0, 1, 0, 0.00], [0, 0, 1, 0.00]], dtype=float)
    P2 = np.array([[1, 0, 0, -0.35], [0, 1, 0, 0.05], [0, 0, 1, 0.00]], dtype=float)
    P3 = np.array([[1, 0, 0, 0.12], [0, 1, 0, -0.28], [0, 0, 1, 0.00]], dtype=float)
    cameras = [P1, P2, P3]
    X_h = np.array([0.25, -0.10, 3.0, 1.0], dtype=float)
    xy_true = np.vstack([project(P, X_h) for P in cameras])
    theta = np.deg2rad(np.array([20.0, -35.0, 70.0]))
    tangent = np.column_stack([np.cos(theta), np.sin(theta)])
    s_true = np.array([0.030, -0.020, 0.025], dtype=float)
    xy_observed = xy_true - s_true[:, None] * tangent
    edge = EdgeCorrespondence(xy=xy_observed, theta=theta, kappa=None, view_ids=(1, 2, 3))
    return edge, pairwise_fundamentals(cameras), xy_true, s_true


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--solver", default="SCS")
    parser.add_argument("--save-fig", default="results/synthetic_refinement.png")
    args = parser.parse_args()

    edge, F_dict, xy_true, s_true = make_problem()
    kwargs = {}
    if args.solver.upper() == "SCS":
        kwargs.update(eps=1e-7, max_iters=50000)

    result = solve_edge_correspondence_eq5_sdr(
        edge, F_dict, solver=args.solver, constraint_mode="reduced", anchor_pair=(1, 2), **kwargs
    )
    sol = result["edge_solution"]
    print("status:", result["status"])
    print("metrics:", result["metrics"])
    print("estimated s:", sol["s"])
    print("known s_true:", s_true)
    print("max |xy_est - xy_true|:", float(np.max(np.abs(sol["xy_linear"] - xy_true))))
    plot_edge_refinement(edge.xy, sol["xy_linear"], save_path=args.save_fig, show=False)
    print("saved figure:", args.save_fig)


if __name__ == "__main__":
    main()
