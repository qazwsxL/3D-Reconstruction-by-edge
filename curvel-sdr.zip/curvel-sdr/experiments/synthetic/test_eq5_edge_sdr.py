#!/usr/bin/env python3
"""
Synthetic sanity test for the Eq. (5) edge-correspondence SDR code.

Put this file inside the CV1430 project folder, next to qcqp_sdr_core.py, then run:

    python test_eq5_edge_sdr.py

To also solve the SDR, install cvxpy and run:

    python test_eq5_edge_sdr.py --solve --solver SCS

This test does not need index_pairs_3D_2D_0006.mat. It creates a tiny synthetic
3-view edge correspondence with a known ground-truth arc-length correction s.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

import numpy as np

# Allow running from the project root or from another working directory.
THIS_DIR = Path(__file__).resolve().parent
if str(THIS_DIR) not in sys.path:
    sys.path.insert(0, str(THIS_DIR))

try:
    from qcqp_sdr_core import (  # noqa: E402
        EdgeCorrespondence,
        build_eq5_sdr_problem,
        constraint_residuals,
        objective_value,
        recover_edge_solution_from_arc_lengths,
        solve_edge_correspondence_eq5_sdr,
    )
except ModuleNotFoundError:
    # Fallback for running next to the standalone file from this chat.
    from qcqp_sdr_core_eq5_edge import (  # type: ignore  # noqa: E402
        EdgeCorrespondence,
        build_eq5_sdr_problem,
        constraint_residuals,
        objective_value,
        recover_edge_solution_from_arc_lengths,
        solve_edge_correspondence_eq5_sdr,
    )


def skew(v: np.ndarray) -> np.ndarray:
    """Return the 3x3 cross-product matrix [v]_x."""
    v = np.asarray(v, dtype=float).reshape(3)
    return np.array(
        [
            [0.0, -v[2], v[1]],
            [v[2], 0.0, -v[0]],
            [-v[1], v[0], 0.0],
        ]
    )


def camera_center(P: np.ndarray) -> np.ndarray:
    """Return homogeneous camera center C satisfying P C = 0."""
    _, _, Vt = np.linalg.svd(P)
    C = Vt[-1]
    return C / C[-1]


def fundamental_from_projections(P_i: np.ndarray, P_j: np.ndarray) -> np.ndarray:
    """
    Compute F_ij such that x_j.T @ F_ij @ x_i = 0.

    Formula: F_ij = [e_j]_x P_j pinv(P_i), where e_j = P_j C_i and C_i is
    the center of camera i.
    """
    C_i = camera_center(P_i)
    e_j = P_j @ C_i
    F = skew(e_j) @ P_j @ np.linalg.pinv(P_i)
    norm = np.linalg.norm(F)
    if norm > 0:
        F = F / norm
    return F


def project(P: np.ndarray, X_h: np.ndarray) -> np.ndarray:
    """Project a homogeneous 3D point into inhomogeneous normalized image coords."""
    x = P @ X_h
    return x[:2] / x[2]


def make_synthetic_problem():
    """
    Create a 3-view example.

    xy_true is exactly epipolar-consistent because it comes from one 3D point.
    xy_observed is xy_true moved along each local edge tangent by -s_true.
    Therefore, the expected correction is approximately s_true.
    """
    # Simple normalized pinhole cameras: P = [I | t].
    P1 = np.array([[1, 0, 0, 0.00], [0, 1, 0, 0.00], [0, 0, 1, 0.00]], dtype=float)
    P2 = np.array([[1, 0, 0, -0.35], [0, 1, 0, 0.05], [0, 0, 1, 0.00]], dtype=float)
    P3 = np.array([[1, 0, 0, 0.12], [0, 1, 0, -0.28], [0, 0, 1, 0.00]], dtype=float)
    cameras = [P1, P2, P3]

    X_h = np.array([0.25, -0.10, 3.0, 1.0], dtype=float)
    xy_true = np.vstack([project(P, X_h) for P in cameras])

    theta = np.deg2rad(np.array([20.0, -35.0, 70.0]))
    tangent = np.column_stack([np.cos(theta), np.sin(theta)])

    s_true = np.array([0.030, -0.020, 0.025], dtype=float)
    xy_observed = xy_true - s_true[:, None] * tangent

    edge = EdgeCorrespondence(
        xy=xy_observed,
        theta=theta,
        # Keep kappa=None here so the exact curvel and the linearized curvel agree.
        kappa=None,
        view_ids=(1, 2, 3),
    )

    F_dict = {}
    for i, P_i in enumerate(cameras, start=1):
        for j, P_j in enumerate(cameras, start=1):
            if i == j:
                continue
            F_dict[(i, j)] = fundamental_from_projections(P_i, P_j)

    return edge, F_dict, xy_true, s_true


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--solve", action="store_true", help="also solve the SDR with cvxpy")
    parser.add_argument("--solver", default="SCS", help="cvxpy solver name, e.g. SCS, CLARABEL, MOSEK")
    parser.add_argument("--verbose", action="store_true", help="verbose cvxpy output")
    args = parser.parse_args()

    np.set_printoptions(precision=8, suppress=True)

    edge, F_dict, xy_true, s_true = make_synthetic_problem()
    problem = build_eq5_sdr_problem(
        edge=edge,
        F_dict=F_dict,
        constraint_mode="reduced",
        anchor_pair=(1, 2),
    )

    y_zero = np.r_[np.zeros(edge.n_views), 1.0]
    y_true = np.r_[s_true, 1.0]

    X_zero = np.outer(y_zero, y_zero)
    X_true = np.outer(y_true, y_true)

    print("=== Eq. (5) edge SDR synthetic test ===")
    print("n_views:", edge.n_views)
    print("M shape:", problem.M.shape)
    print("A shape:", problem.A.shape)
    print("H shape:", problem.H.shape)
    print("selected F pairs:", list(problem.F_selected.keys()))
    print()

    print("observed xy:")
    print(edge.xy)
    print("true epipolar-consistent xy:")
    print(xy_true)
    print("known s_true:", s_true)
    print()

    print("max |constraint residual| at s=0:", np.max(np.abs(constraint_residuals(problem.A, X_zero))))
    print("max |constraint residual| at s_true:", np.max(np.abs(constraint_residuals(problem.A, X_true))))
    print("objective at s=0:", objective_value(problem.M, X_zero))
    print("objective at s_true:", objective_value(problem.M, X_true))

    recovered_from_true = recover_edge_solution_from_arc_lengths(problem, y_true)
    print("recovered xy from known s_true:")
    print(recovered_from_true["xy_linear"])
    print("max |recovered_xy - xy_true|:", np.max(np.abs(recovered_from_true["xy_linear"] - xy_true)))

    if not args.solve:
        print()
        print("Matrix-construction test finished. Add --solve to run the SDP solver.")
        return

    print()
    print(f"Solving SDR with cvxpy solver={args.solver!r} ...")
    try:
        result = solve_edge_correspondence_eq5_sdr(
            edge=edge,
            F_dict=F_dict,
            constraint_mode="reduced",
            anchor_pair=(1, 2),
            solver=args.solver,
            verbose=args.verbose,
            eps=1e-7 if args.solver.upper() == "SCS" else None,
            max_iters=50000 if args.solver.upper() == "SCS" else None,
        )
    except TypeError:
        # Some solvers do not accept eps/max_iters. Retry with only common args.
        result = solve_edge_correspondence_eq5_sdr(
            edge=edge,
            F_dict=F_dict,
            constraint_mode="reduced",
            anchor_pair=(1, 2),
            solver=args.solver,
            verbose=args.verbose,
        )
    except ImportError as exc:
        print("Could not solve because cvxpy is not installed:")
        print(exc)
        print("Install it with: pip install cvxpy")
        return

    sol = result["edge_solution"]
    print("status:", result["status"])
    print("metrics:", result["metrics"])
    print("estimated s:", sol["s"])
    print("known s_true:", s_true)
    print("s error:", sol["s"] - s_true)
    print("estimated refined xy:")
    print(sol["xy_linear"])
    print("max |estimated_xy - xy_true|:", np.max(np.abs(sol["xy_linear"] - xy_true)))


if __name__ == "__main__":
    main()
