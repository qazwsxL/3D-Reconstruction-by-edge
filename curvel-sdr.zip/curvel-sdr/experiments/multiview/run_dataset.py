#!/usr/bin/env python3
"""Dataset entry point template.

Expected NPZ format:
    xy:    (N, 2)
    theta: (N,)
    kappa: (N,) optional
    F_keys: (M, 2) 1-based view pairs
    F:     (M, 3, 3)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from curvel_sdr.core.qcqp_sdr_core_eq5_edge import EdgeCorrespondence, solve_edge_correspondence_eq5_sdr


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("npz_path")
    parser.add_argument("--solver", default="SCS")
    parser.add_argument("--mode", choices=["reduced", "full"], default="reduced")
    args = parser.parse_args()

    data = np.load(args.npz_path)
    xy = data["xy"]
    theta = data["theta"]
    kappa = data["kappa"] if "kappa" in data.files else None
    F_keys = data["F_keys"]
    F_arr = data["F"]
    F_dict = {(int(pair[0]), int(pair[1])): F_arr[idx] for idx, pair in enumerate(F_keys)}

    edge = EdgeCorrespondence(xy=xy, theta=theta, kappa=kappa)
    kwargs = {"eps": 1e-6, "max_iters": 50000} if args.solver.upper() == "SCS" else {}
    result = solve_edge_correspondence_eq5_sdr(edge, F_dict, solver=args.solver, constraint_mode=args.mode, **kwargs)
    print("status:", result["status"])
    print("metrics:", result["metrics"])
    print("arc lengths s:", result["edge_solution"]["s"])
    print("refined xy:")
    print(result["edge_solution"]["xy_linear"])


if __name__ == "__main__":
    main()
