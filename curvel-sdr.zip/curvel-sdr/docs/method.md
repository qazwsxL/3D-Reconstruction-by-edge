# Method Summary

## 1. Curvel modeling

For each edge anchor `(x_i, y_i, theta_i, kappa_i)`, the local curve is parameterized by arc length `s_i`:

```text
theta_i(s_i) = theta_i + kappa_i s_i
```

and the exact curvel point follows the integrated tangent field. When curvature is near zero, the model degenerates to a line.

## 2. Eq. (5) reduced edge formulation

The optimized variable is the arc-length vector

```text
y = [s_1, ..., s_N, 1]^T.
```

The first-order curvel approximation defines an affine map `C = H y`, where `C` stacks all refined edge locations. Epipolar constraints are projected through this map, giving quadratic constraints in `y`.

## 3. SDR relaxation

The non-convex QCQP is lifted with `X = y y^T`. Dropping the rank-one constraint yields an SDP:

```text
min trace(M X)
s.t. trace(A_k X) = 0
     X[-1, -1] = 1
     X >= 0
```

If the recovered solution is rank one, the arc lengths and refined edge points are recovered exactly from the leading eigenvector.
